==================
Cloud/CLI trainer
==================

.. automodule:: pinn.trainer
