=====
PiNet
=====

.. autofunction:: pinn.networks.pinet
