====
BPNN
====

Behler-Parrinello Neural Network, see
ref. :cite:`behler_constructinghighdimensionalneural_2015` for details.

.. autofunction:: pinn.networks.bpnn
