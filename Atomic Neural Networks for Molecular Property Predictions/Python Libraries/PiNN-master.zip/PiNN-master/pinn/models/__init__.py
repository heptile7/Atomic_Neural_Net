# -*- coding: utf-8 -*-
from pinn.models.potential import potential_model
from pinn.models.dipole import dipole_model
