#ifndef __SPGCH_H__
#define __SPGCH_H__

#include "asapbrenner.h"

namespace ASAPSPACE {

extern const Float SPGC[5+1][6+1];
extern const Float SPGH[3+1][6+1];

} // end namespace

#endif
