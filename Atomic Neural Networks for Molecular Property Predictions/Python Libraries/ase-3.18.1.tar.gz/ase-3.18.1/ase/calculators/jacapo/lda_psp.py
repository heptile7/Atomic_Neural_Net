# Copyright (C) 2005 jrk

""" Default pseudopotential paths are defined here
"""

__docformat__ = 'reStructuredText'

defaultpseudopotentials = {}

