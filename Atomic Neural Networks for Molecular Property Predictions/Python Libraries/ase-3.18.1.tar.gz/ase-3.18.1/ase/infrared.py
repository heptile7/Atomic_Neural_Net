import warnings
from vibrations.infrared import InfraRed
__all__ = ['InfraRed']

warnings.warn('Renamed to ase.vibrations.infrared.Infrared')
